public class KarelProgram extends Karel
{
    public void run()
    {
        letterC();
        returnToStart();
        collectBalls();
        returnToStart();
        letterA();
        returnToStart();
        collectBalls();
        returnToStart();
        letterR();
        
    }
    private void collectBalls() {
        while (frontIsClear()) {
            collectRow();
            moveToNextRow();
        }
        collectRow();
    }
    private void collectRow() {
        while (frontIsClear()) {
            if (ballsPresent()) {
                takeBall();
            }
            move();
        }
        if (ballsPresent()) {
            takeBall();
        }
    }
    private void moveToNextRow() {
        if (facingEast()) {
            turnLeft();
            if (frontIsClear()) {
                move();
                turnLeft();
            }
        } else if (facingWest()) {
            turnRight();
            if (frontIsClear()) {
                move();
                turnRight();
            }
        }
    }
    private void returnToStart() {
        while (notFacingWest()) {
            turnLeft();
        }
        while (frontIsClear()) {
            move();
        }
        turnLeft();
        while (frontIsClear()) {
            move();
        }
        turnLeft();
    }
    void turnRight() {
        turnLeft();
        turnLeft();
        turnLeft();
    }
    void turnAround() {
        turnLeft();
        turnLeft();
    }  
    void letterC() {
        turnLeft();
        for (int i=0; i<9; i++) {
            putBall();
            move();
        }
        turnRight();
        for (int j=0; j<7; j++) {
            putBall();
            move();
        }
        turnAround();
        for (int k=0; k<7; k++) {
            move();
        }
        turnLeft();
        for (int k=0; k<9; k++) {
            move();
        }
        turnLeft();
        for (int i=0; i<7; i++) {
            putBall();
            move();
        }
        
    }
    void letterA() {
        turnLeft();
       for (int i=0; i<9; i++) {
            putBall();
            move();
       }
      turnRight();
        for (int j=0; j<4; j++) {
            putBall();
            move();
        }
        turnRight();
        for (int j=0; j<4; j++) {
            putBall();
            move();
        }
        turnRight();
        for (int j=0; j<4; j++) {
            putBall();
            move();
        }
        turnAround();
        for (int j=0; j<4; j++) {
            move();
        }
        turnRight();
        for (int k=0; k<5; k++) {
            putBall();
            move();
        }
    }
    void letterR() {
        turnLeft();
       for (int i=0; i<9; i++) {
            putBall();
            move();
       }
      turnRight();
        for (int j=0; j<4; j++) {
            putBall();
            move();
        }
        turnRight();
        for (int j=0; j<4; j++) {
            putBall();
            move();
        }
        turnRight();
        for (int j=0; j<4; j++) {
            putBall();
            move();
        }
        turnLeft();
        move();
        turnLeft();
        move();
        putBall();
        turnRight();
        move();
        turnLeft();
        move();
        putBall();
         turnRight();
        move();
        turnLeft();
        move();
        putBall();
         turnRight();
        move();
        turnLeft();
        move();
        putBall();
         turnRight();
        move();
        turnLeft();
        move();
        putBall();
    }
}